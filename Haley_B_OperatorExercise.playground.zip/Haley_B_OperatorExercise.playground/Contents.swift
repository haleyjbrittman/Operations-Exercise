import UIKit

//First Section
var a = 10
var b = 2
var c = 5

//Second Section
(a * b)
(b + c)
(a - b)
(a/c)

//Third Section
print (a * b)
print (b + c)
print (a - b)
print (a / c)
